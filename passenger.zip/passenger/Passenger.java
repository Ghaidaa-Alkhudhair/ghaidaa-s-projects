//Ghaida Alkhudhair 441926684


public class Passenger {
    private String name;
    private Bag[] baglist;
    private int numOfBags;
    
    Passenger(String name, int size){
        baglist=new Bag[size];
        numOfBags=0;
        
    }
    void addBag(Bag b){
        if(numOfBags<baglist.length){
           baglist[numOfBags]=b;
        numOfBags++;}
        else 
            System.out.println("sorry you can not add more bags!!");
}
    double calTotalWeigth(){
        double sum=0;
        for(int i=0;i<numOfBags;i++){
            sum+=baglist[i].getWeight();}
        return sum;
        
    }
}
