//Ghaida Alkhudhair 441926684

public class PassengerApp {
    public static void main(String[] args) {
       Passenger pass=new Passenger("Sarah ali",5) ;
       Bag b1=new Bag(11,30);
       Bag b2=new Bag(22,55);
       Bag b3=new Bag(33,20);
       pass.addBag(b1);
         pass.addBag(b2);
           pass.addBag(b3);
           System.out.println("the total weight of the bags is :"+ pass.calTotalWeigth());
       
        
    }
    
}
