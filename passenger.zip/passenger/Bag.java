//Ghaida Alkhudhair 441926684

public class Bag {
    private int ID;
    private double weight;
    Bag(int ID,double weight){
        this.ID=ID;
        this.weight=weight;
    }

    @Override
    public String toString() {
        return "Bag{" + "ID=" + ID + ", weight=" + weight + '}';
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }
    
    
}
