//Ghaida alkhudhair 441926684
//Atheer alhkamali 439200223
//Athari alshehri 441201001 
public class Employee {
   private String ID; //string becuase it will not be used as a number .
   private String JobTitle; // String since it is a text.
   private String ContractDate;// we declear it as int since later it will be cut.
   private String StartTime; // we declear it as string since later it will be cut.
   private String EndTime;// we declear itas string since later it will be cut.
   private boolean Hired; //boolean because it give a true or false value.
   private int Frequency; // we declear it as int because it is number of time can not be double.
   public Employee (String id,String title,String date ,String start_t ,String end_t, boolean hired , int f)//constructor that inetialize value to the variables.
   {
      ID=id;
      JobTitle= title;
      ContractDate=date;
      StartTime=start_t;
      EndTime=end_t;
      Hired=hired;
      Frequency=f;
   }
   public int CalculateDuration()// the calculate duration method that calculate and returns the total duration (in hours) of the current hiring contract.  
   {
      String Startt=StartTime.substring(0,StartTime.indexOf(':'));//cut the number till reaching the ':'
      String endt=EndTime.substring(0,EndTime.indexOf(':'));//cut the number till reaching the ':'
   
      int start1=Integer.parseInt(Startt);//to convert the string to integer
      int end1=Integer.parseInt(endt);//to convert the string to integer
      int total=end1-start1; //calcuate the total duration by subtract the end hours from the start hours,
      if (total==0)//the minimum hours is = one .
         total=1;
   
      return total; //return the total duration
   }

   public void updateFrequency()//the update Frequency method that increment the frequency by one.
   {
      Frequency++; //increment
   }
   public void displayInfo()// method that print the out put
   {
      System.out.printf("|%-12s|%15s|%10s|%6s|%6s|%-4s|%-4d|\n",ID,JobTitle,ContractDate,StartTime,EndTime,(Hired?"Yes":"No") ,Frequency);// the output formating as required
   
   
   }
   public String getid()// method get ID
   {
      return ID ; 
   }
   public void setId(String id)//set ID
   {
      ID = id;
   }


   public String getjobtitle() //method get jop title 
   {
      return JobTitle ;
   }
   public void setJobtitle(String jobtitle) //method set jop title
   {
      JobTitle = jobtitle;
   }

   public String getcontractdate() //method get contract date 
   {
      return ContractDate ;
   }
   public void setContractdate(String contractdate)//method set contract date 
   {
      ContractDate = contractdate;
   }

   public String getstarttime()//method get start time
   {
      return StartTime;
   }
   public void setStarttime(String starttime) //method set start time
   {
      StartTime = starttime;
   }

   public String getendtime() //method get end time
   {
      return EndTime ;
   }
   public void setEndtime(String endtime) //method set end time
   {
      EndTime = endtime;
   }


   public boolean gethired()//method get hired
   {
      return Hired;
   }
   public void setHired(boolean hired) //method set hired
   {
      Hired= hired;
   }
   public int getfrequency() //method get frequency
   {
      return Frequency;
   }
   public void setFrequency(int frequency) //method set frequency
   {
      Frequency = frequency;
   }







}


