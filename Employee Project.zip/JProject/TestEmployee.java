import java.util.*;
public class TestEmployee {

//Create an array of size 100 and name it: hiringEmployees
static Employee hiringEmployees[] = new Employee[100] ; 
static int count ;

public static void main(String [] args) {

Scanner console = new Scanner (System.in);

//Fill-in the array with the 10 employees,
hiringEmployees[0] = new Employee("9876543222","Driver","15/12/2020","16:00","22:00",true,1);
hiringEmployees[1] = new Employee("9876543211","Cleaning Worker","15/12/2020","08:00","16:00",true,4);
hiringEmployees[2] = new Employee("1234567899","Cleaning Worker","N/A","N/A","N/A",false,0);
hiringEmployees[3] = new Employee("2234567891","Cleaning Worker","17/12/2020","08:00","13:00",true,2);
hiringEmployees[4] = new Employee("1334567892","Driver","11/12/2020","10:00","15:00",true,1);
hiringEmployees[5] = new Employee("4412356789","Cleaning Worker","05/12/2020","12:00","16:00",true,10);
hiringEmployees[6] = new Employee("3114567894","Driver","N/A","N/A","N/A",false,2);
hiringEmployees[7] = new Employee("8876543221","Driver","19/12/2020","08:00","14:00",true,1); 
hiringEmployees[8] = new Employee("7776543267","Cleaning Worker","N/A","N/A","N/A",false,3); 
hiringEmployees[9] = new Employee("1176543266","Cleaning Worker","02/12/2020","17:00","21:00",true,12); 
count = 10 ; 

//Display which employee has the maximum frequency: 9876543211 or 1234567899?
String idMax =  maximumFrequency(hiringEmployees[1] , hiringEmployees[2]);
if(idMax.equals("-1"))
System.out.println("Employees have different job titles");
else
System.out.println("Employee with the id number:("+ idMax +") can take a break during the weekend"); 

//Display which employee worked for less duration: 9876543222 or 9876543211? 
String idMin = minimumDuration(hiringEmployees[0] , hiringEmployees[1]);
if (idMin.equals("Dates are Mismatched"))
System.out.println("Employees worked in a different date");
else
System.out.println("Employee with the id number: ("+ idMin +") worked less on ("+ hiringEmployees[0].getcontractdate() + ")"); 

//Display which employee has maximum frequency: 9876543211 or 9876543222?
idMax = maximumFrequency(hiringEmployees[0] , hiringEmployees[1]);
if( idMax.equals("-1"))
System.out.println("Employees have different job titles");
else
System.out.println("Employee with the id number: ("+ idMax +") can take a break during the weekend "); 


//Display which employee worked for less duration: 9876543211 or 2234567891?
idMin = minimumDuration(hiringEmployees[1] , hiringEmployees[3]);
if( idMin.equals("Dates are Mismatched"))
System.out.println("Employees worked in a different date");
else
System.out.println("Employee with the id number: ("+ idMin +") worked less on ("+ hiringEmployees[1].getcontractdate() +") "); 

int selection;  
 do{
 System.out.println("* Welcome to HRS system *\n please manage the hiring process for all the employees by selecting one of the following"); 
  System.out.println("1. Add a new employee \n"+
                     "2. Start a hiring contract \n"+
                     "3. End a hiring contract \n"+
                     "4. Display employee info \n"+
                     "5. Display HRS system status \n"+
                     "6. Exit \n");
selection = console.nextInt();

switch( selection ){
 
 case 1:
  if (count == hiringEmployees.length){
   System.out.println("sorry you can`t add more than 100");
   break;}
  System.out.println("please enter the employee�s ID ");
  String ID =console.next();
  
  boolean exist = false;//if id exist
  for (int i =0 ; i<count ;i++)
  if (hiringEmployees[i].getid().equals(ID)){
  System.out.println("this ID is already exist.");
  exist = true ;
  }
  if (exist == true)
  break;
  
  System.out.println("please enter the job title: ");
  console.nextLine();//fix entring issue 
  String job = console.nextLine();
  hiringEmployees[count]= new Employee (ID ,job , "N/A" , "N/A" , "N/A" , false ,0);   
  count++;
  System.out.println("the process of adding employee is done successfully"); 
 break;
 
 case 2:
 System.out.println("please enter the employee�s ID ");
 String I_D =console.next();
 boolean exist2 = true; //checking if the employee is exist or not
 int employee =0;
 for(int i = 0 ; i<count ;i++)
 if (hiringEmployees[i].getid().equals(I_D)){
 exist2 = false;
 employee=i;
 }
 if (exist2==true)
 {
  System.out.println("sorry the employee dosen`t exist"); 
  break;//out case2
 }
 if(hiringEmployees[employee].gethired()==true)
  {
  System.out.println("sorry this employee is already hired"); 
  break;//out case2
 }
 System.out.println("please enter the contract date formated as (mm/dd/yyyy): ");
  String contactDate=console.next();
  hiringEmployees[employee].setContractdate(contactDate);
 System.out.println("please enter the start time formated as (HH:00): ");
  String statrTime=console.next();
  hiringEmployees[employee].setStarttime(statrTime);
 System.out.println("please enter the start time formates as (HH:00): ");
  String endTime=console.next();
  hiringEmployees[employee].setEndtime(endTime);
  
 hiringEmployees[employee].setHired(true);
 hiringEmployees[employee].updateFrequency();
 hiringEmployees[employee].displayInfo();
 System.out.println("**the employee is now ready for starting the assigned job.**");
  
 break;
 
 case 3:
 System.out.println("please enter the employee�s ID ");
  I_D =console.next();
 boolean exist3 = true; //checking if the employee is exist or not
  employee =0;
 for(int i = 0 ; i<count ;i++)
 if (hiringEmployees[i].getid().equals(I_D)){
 exist3 = false;
 employee=i;
 }
 if (exist3 ==true)
 {
  System.out.println("sorry the employee dosen`t exist"); 
  break;//out case3
 }
 if(hiringEmployees[employee].gethired()==false)
  {
  System.out.println("sorry this employee is not hired"); 
  break;//out case3
}
 System.out.println("Employee information: ");
 hiringEmployees[employee].displayInfo();
 System.out.println("and cotracts total duration is: "+hiringEmployees[employee].CalculateDuration());// inform 
 //hiringEmployees[employee].CalculateDuration();
 hiringEmployees[employee].setContractdate("N/A");
 hiringEmployees[employee].setStarttime("N/A");
 hiringEmployees[employee].setEndtime("N/A"); 
 hiringEmployees[employee].setHired(false);

 break;
 
 case 4:
 System.out.println("please enter the employee�s ID ");
 I_D =console.next();
 boolean exist4 = true; //checking if the employee is hired or not
 employee =0;
 for(int i = 0 ; i<count ;i++)//mf
 if (hiringEmployees[i].getid().equals(I_D)){
 exist4 = false;
 employee=i;
 }
 if (exist4 ==true)
 {
  System.out.println("sorry the employee dosen`t exist"); 
  break;//out case4
 }
 hiringEmployees[employee].displayInfo();
 break;
 
 case 5:
 int hired =0; 
 int available=0;
 for(int i = 0 ; i<count ;i++)
  if (hiringEmployees[i].gethired()==true)
  hired++;
  else
  available++;
  
  int highest =0 ;
  for( int i= 1; i<count; i++)
  if (hiringEmployees[i].getfrequency()> hiringEmployees[highest].getfrequency())
  highest=i;
  
  System.out.println("The total number of employees who are currently registered in the system is: "+count);
  System.out.println("The current number of hired employees is :"+hired);
  System.out.println("the number of available employees is: "+available);
  System.out.println("The id of the employee with the highest hiring frequency in the system."+hiringEmployees[highest].getid());
  System.out.println("Table of all the listing employees:");
  System.out.printf("|%-12s|%-15s|%-10s|%-6s|%-6s|%-4s|%-4s|\n","ID","Job Title","Contract Date","Start Time","End Time","Hired?","Frequency");
  for( int i=0; i<count; i++)
   hiringEmployees[i].displayInfo();
 break;
 
 case 6:
 System.out.println("All info will be lost  Are you sure you want to exit? (Yes/No)");
 String exite = console.next();
 if (exite.equalsIgnoreCase("yes"))
  System.out.println("Thank you, hope we served you will, have a nice day");
 else if (exite.equalsIgnoreCase("no"))
  selection = 0;
  else
   {System.out.println("only (yes/no) is accepted!");
   selection = 0;}
 break;
 
 default:
 System.out.println("Not valid selection!");

}//end switch 

}while(selection != 6); // end do-while
 


} // end main

public static String maximumFrequency(Employee one, Employee two) { 
if (one.getjobtitle().equalsIgnoreCase(two.getjobtitle()) )
if (one.getfrequency() >= two.getfrequency())
return one.getid();
else
return two.getid();

return "-1";
} // end method

public static String minimumDuration(Employee one, Employee two) {

if( one.getcontractdate().equalsIgnoreCase(two.getcontractdate()) ) {
if( one.CalculateDuration()<= two.CalculateDuration() )
return one.getid(); 
else
return two.getid(); 
}

return "Dates are Mismatched" ; 
} // end method

} // end class