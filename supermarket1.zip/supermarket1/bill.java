package supermarket;
//Ghaida Alkhudhair 441926684
public class bill {
    private int bNo;
    private String date;
    private double price;
    private double tax;
    private int award;
    public static int counter;
 
  bill(int no, String d, double p, double t ){
      bNo=no;
      date=d;
      price=p;
      tax=t;
      counter++;
      set_award();
      
  }
  public void set_award(){
      if(price>200)
          award+=10;
  }
  public double get_cost(){
      double cost;
      cost=price+tax*price;
      return cost;
  }
  public int getNo(){
      return bNo;
  }
  public void print(){
      System.out.println(bNo+"|"+get_cost()+"|"+award);
  }
}
