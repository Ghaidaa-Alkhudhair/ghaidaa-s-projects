
package supermarket;
//Ghaida Alkhudhair 441926684
public class Supermarket {
    public static void main(String[] args) {
        bill Bill1=new bill(1045,"12/1/2018",150,0.02);
        bill Bill2=new bill(1066,"20/8/2018",300,0.05);
        Bill1.print();
        Bill2.print();
    }
     
}
